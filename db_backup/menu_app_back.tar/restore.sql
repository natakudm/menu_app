--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 9.6.9
-- Dumped by pg_dump version 9.6.9

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

ALTER TABLE ONLY public.dish DROP CONSTRAINT fk_wine_dish;
ALTER TABLE ONLY public.meal DROP CONSTRAINT fk_reataurant_meal;
ALTER TABLE ONLY public.dish DROP CONSTRAINT fk_meal_dish;
ALTER TABLE ONLY public.dish DROP CONSTRAINT fk_day_dish;
ALTER TABLE ONLY public.cocktail DROP CONSTRAINT fk_day_cocktail;
ALTER TABLE ONLY public.day DROP CONSTRAINT fk_cruise_day;
DROP INDEX public.meal_name_index;
DROP INDEX public.dish_name_index;
ALTER TABLE ONLY public.wine DROP CONSTRAINT pk_vine;
ALTER TABLE ONLY public.restaurant DROP CONSTRAINT pk_restaurant;
ALTER TABLE ONLY public.meal DROP CONSTRAINT pk_meal;
ALTER TABLE ONLY public.dish DROP CONSTRAINT pk_dish;
ALTER TABLE ONLY public.day DROP CONSTRAINT pk_day;
ALTER TABLE ONLY public.cruise DROP CONSTRAINT pk_cruise;
ALTER TABLE ONLY public.cocktail DROP CONSTRAINT pk_cocktail;
ALTER TABLE public.wine ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.meal ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.dish ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.day ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.cocktail ALTER COLUMN id DROP DEFAULT;
DROP SEQUENCE public.vine_id_seq;
DROP SEQUENCE public.meal_id_seq;
DROP VIEW public.lunch_view;
DROP VIEW public.dish_view;
DROP SEQUENCE public.dish_id_seq;
DROP VIEW public.dinner_view;
DROP TABLE public.wine;
DROP VIEW public.dinner_restaurant_view;
DROP SEQUENCE public.day_id_seq;
DROP TABLE public.day;
DROP TABLE public.cruise;
DROP SEQUENCE public.cocktail_id_seq;
DROP TABLE public.cocktail;
DROP VIEW public.breakfast_view;
DROP TABLE public.restaurant;
DROP SEQUENCE public.restaurant_id_seq;
DROP TABLE public.meal;
DROP TABLE public.dish;
DROP TYPE public.restaurant_enum_type;
DROP TYPE public.meal_enum_type;
DROP TYPE public.dish_enum_type;
DROP EXTENSION plpgsql;
DROP SCHEMA public;
--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO postgres;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS 'standard public schema';


--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


--
-- Name: dish_enum_type; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.dish_enum_type AS ENUM (
    'appetizer',
    'soup',
    'salad',
    'mc',
    'dessert',
    'breakfast',
    'breakfask_sp',
    'breakfast_sp',
    'pasta',
    'teatime'
);


ALTER TYPE public.dish_enum_type OWNER TO postgres;

--
-- Name: meal_enum_type; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.meal_enum_type AS ENUM (
    'breakfast',
    'lunch',
    'teatime',
    'dinner',
    'dinner_sp'
);


ALTER TYPE public.meal_enum_type OWNER TO postgres;

--
-- Name: restaurant_enum_type; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.restaurant_enum_type AS ENUM (
    'traditional',
    'anytime',
    'special',
    'italian',
    'steak'
);


ALTER TYPE public.restaurant_enum_type OWNER TO postgres;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: dish; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.dish (
    id integer NOT NULL,
    name character varying(255),
    description text,
    picture character varying(255),
    category public.dish_enum_type,
    id_meal smallint DEFAULT 9,
    recomended_wine smallint,
    id_day smallint DEFAULT 1
);


ALTER TABLE public.dish OWNER TO postgres;

--
-- Name: meal; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.meal (
    id integer NOT NULL,
    id_restaurant smallint NOT NULL,
    name public.meal_enum_type,
    time_open time without time zone,
    time_close time without time zone
);


ALTER TABLE public.meal OWNER TO postgres;

--
-- Name: restaurant_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.restaurant_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.restaurant_id_seq OWNER TO postgres;

--
-- Name: restaurant; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.restaurant (
    id smallint DEFAULT nextval('public.restaurant_id_seq'::regclass) NOT NULL,
    name character varying(32) NOT NULL,
    location character varying(32),
    description text,
    picture character varying(255),
    restaurant_type public.restaurant_enum_type,
    price numeric(5,2)
);


ALTER TABLE public.restaurant OWNER TO postgres;

--
-- Name: breakfast_view; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public.breakfast_view AS
 SELECT dish.name,
    dish.description,
    dish.picture,
    restaurant.name AS restaurant_name,
    meal.time_open,
    meal.time_close
   FROM ((public.dish
     LEFT JOIN public.meal ON ((dish.id_meal = meal.id)))
     LEFT JOIN public.restaurant ON ((meal.id_restaurant = restaurant.id)));


ALTER TABLE public.breakfast_view OWNER TO postgres;

--
-- Name: cocktail; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.cocktail (
    id integer NOT NULL,
    name character varying(32),
    description text,
    price numeric(7,2) DEFAULT 5.99,
    picture character varying(255),
    id_day smallint
);


ALTER TABLE public.cocktail OWNER TO postgres;

--
-- Name: cocktail_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.cocktail_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.cocktail_id_seq OWNER TO postgres;

--
-- Name: cocktail_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.cocktail_id_seq OWNED BY public.cocktail.id;


--
-- Name: cruise; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.cruise (
    id_code character varying(32) NOT NULL,
    name character varying(64),
    description text
);


ALTER TABLE public.cruise OWNER TO postgres;

--
-- Name: day; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.day (
    id integer NOT NULL,
    name character varying(64),
    description text,
    id_cruise character varying(32),
    cocktail_of_the_day smallint
);


ALTER TABLE public.day OWNER TO postgres;

--
-- Name: day_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.day_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.day_id_seq OWNER TO postgres;

--
-- Name: day_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.day_id_seq OWNED BY public.day.id;


--
-- Name: dinner_restaurant_view; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public.dinner_restaurant_view AS
 SELECT restaurant.name,
    restaurant.restaurant_type,
    restaurant.location,
    restaurant.price,
    meal.time_open,
    meal.time_close
   FROM (public.restaurant
     LEFT JOIN public.meal ON (((meal.id_restaurant = restaurant.id) AND (meal.name = 'dinner'::public.meal_enum_type))));


ALTER TABLE public.dinner_restaurant_view OWNER TO postgres;

--
-- Name: wine; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.wine (
    id integer NOT NULL,
    name character varying(64),
    description text,
    price_for_glass numeric(5,2) DEFAULT 5.95,
    price_for_bottle numeric(6,2) DEFAULT 29.95,
    picture character varying(255)
);


ALTER TABLE public.wine OWNER TO postgres;

--
-- Name: dinner_view; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public.dinner_view AS
 SELECT dish.id,
    dish.category,
    dish.name,
    dish.description,
    dish.picture AS dish_picture,
    wine.name AS wine_name,
    wine.description AS wine_description,
    wine.price_for_glass,
    wine.price_for_bottle,
    wine.picture AS wine_picture
   FROM (((public.dish
     LEFT JOIN public.wine ON ((dish.recomended_wine = wine.id)))
     LEFT JOIN public.meal ON ((dish.id_meal = meal.id)))
     LEFT JOIN public.restaurant ON ((meal.id_restaurant = restaurant.id)))
  WHERE (((dish.id_day = 0) OR (dish.id_day = 1)) AND (meal.name = 'dinner'::public.meal_enum_type) AND (restaurant.restaurant_type = 'traditional'::public.restaurant_enum_type))
  ORDER BY dish.id;


ALTER TABLE public.dinner_view OWNER TO postgres;

--
-- Name: dish_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.dish_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.dish_id_seq OWNER TO postgres;

--
-- Name: dish_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.dish_id_seq OWNED BY public.dish.id;


--
-- Name: dish_view; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public.dish_view AS
 SELECT dish.id,
    dish.id_day,
    dish.category,
    dish.name,
    dish.description,
    dish.picture,
    wine.id AS wine_id,
    wine.name AS wine_name,
    restaurant.name AS restaurant_name,
    meal.name AS meal_name,
    restaurant.restaurant_type
   FROM (((public.dish
     LEFT JOIN public.wine ON ((dish.recomended_wine = wine.id)))
     LEFT JOIN public.meal ON ((dish.id_meal = meal.id)))
     LEFT JOIN public.restaurant ON ((meal.id_restaurant = restaurant.id)));


ALTER TABLE public.dish_view OWNER TO postgres;

--
-- Name: lunch_view; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public.lunch_view AS
 SELECT dish.id,
    dish.category,
    dish.name,
    dish.description,
    dish.picture AS dish_picture,
    restaurant.id AS restaurant_id,
    restaurant.name AS restaurant_name,
    meal.name AS meal_name,
    meal.time_open,
    meal.time_close,
    wine.name AS wine_name,
    wine.description AS wine_description,
    wine.price_for_glass,
    wine.price_for_bottle,
    wine.picture AS wine_picture
   FROM (((public.dish
     LEFT JOIN public.wine ON ((dish.recomended_wine = wine.id)))
     LEFT JOIN public.meal ON ((dish.id_meal = meal.id)))
     LEFT JOIN public.restaurant ON ((meal.id_restaurant = restaurant.id)))
  WHERE (((dish.id_day = 0) OR (dish.id_day = 1)) AND (meal.name = 'lunch'::public.meal_enum_type));


ALTER TABLE public.lunch_view OWNER TO postgres;

--
-- Name: meal_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.meal_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.meal_id_seq OWNER TO postgres;

--
-- Name: meal_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.meal_id_seq OWNED BY public.meal.id;


--
-- Name: vine_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.vine_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.vine_id_seq OWNER TO postgres;

--
-- Name: vine_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.vine_id_seq OWNED BY public.wine.id;


--
-- Name: cocktail id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cocktail ALTER COLUMN id SET DEFAULT nextval('public.cocktail_id_seq'::regclass);


--
-- Name: day id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.day ALTER COLUMN id SET DEFAULT nextval('public.day_id_seq'::regclass);


--
-- Name: dish id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.dish ALTER COLUMN id SET DEFAULT nextval('public.dish_id_seq'::regclass);


--
-- Name: meal id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.meal ALTER COLUMN id SET DEFAULT nextval('public.meal_id_seq'::regclass);


--
-- Name: wine id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.wine ALTER COLUMN id SET DEFAULT nextval('public.vine_id_seq'::regclass);


--
-- Data for Name: cocktail; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/2229.dat

--
-- Name: cocktail_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.cocktail_id_seq', 1, false);


--
-- Data for Name: cruise; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/2233.dat

--
-- Data for Name: day; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/2235.dat

--
-- Name: day_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.day_id_seq', 1, false);


--
-- Data for Name: dish; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/2239.dat

--
-- Name: dish_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.dish_id_seq', 1, true);


--
-- Data for Name: meal; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/2232.dat

--
-- Name: meal_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.meal_id_seq', 1, true);


--
-- Data for Name: restaurant; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/2230.dat

--
-- Name: restaurant_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.restaurant_id_seq', 39, true);


--
-- Name: vine_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.vine_id_seq', 2, true);


--
-- Data for Name: wine; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/2237.dat

--
-- Name: cocktail pk_cocktail; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cocktail
    ADD CONSTRAINT pk_cocktail PRIMARY KEY (id);


--
-- Name: cruise pk_cruise; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cruise
    ADD CONSTRAINT pk_cruise PRIMARY KEY (id_code);


--
-- Name: day pk_day; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.day
    ADD CONSTRAINT pk_day PRIMARY KEY (id);


--
-- Name: dish pk_dish; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.dish
    ADD CONSTRAINT pk_dish PRIMARY KEY (id);


--
-- Name: meal pk_meal; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.meal
    ADD CONSTRAINT pk_meal PRIMARY KEY (id);


--
-- Name: restaurant pk_restaurant; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.restaurant
    ADD CONSTRAINT pk_restaurant PRIMARY KEY (id);


--
-- Name: wine pk_vine; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.wine
    ADD CONSTRAINT pk_vine PRIMARY KEY (id);


--
-- Name: dish_name_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX dish_name_index ON public.dish USING btree (name);


--
-- Name: meal_name_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX meal_name_index ON public.meal USING btree (name);


--
-- Name: day fk_cruise_day; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.day
    ADD CONSTRAINT fk_cruise_day FOREIGN KEY (id_cruise) REFERENCES public.cruise(id_code) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: cocktail fk_day_cocktail; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cocktail
    ADD CONSTRAINT fk_day_cocktail FOREIGN KEY (id_day) REFERENCES public.day(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: dish fk_day_dish; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.dish
    ADD CONSTRAINT fk_day_dish FOREIGN KEY (id_day) REFERENCES public.day(id);


--
-- Name: dish fk_meal_dish; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.dish
    ADD CONSTRAINT fk_meal_dish FOREIGN KEY (id_meal) REFERENCES public.meal(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: meal fk_reataurant_meal; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.meal
    ADD CONSTRAINT fk_reataurant_meal FOREIGN KEY (id_restaurant) REFERENCES public.restaurant(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: dish fk_wine_dish; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.dish
    ADD CONSTRAINT fk_wine_dish FOREIGN KEY (recomended_wine) REFERENCES public.wine(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

